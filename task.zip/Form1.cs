using Newtonsoft.Json;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace WinFormsApp8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            PopulateColorComboBox();
            PopulateFontStyleComboBox();
            PopulateSizeComboBox();
        }

        private void PopulateFontStyleComboBox()
        {
            FontFamily[] fontFamilies = FontFamily.Families;

            foreach (FontFamily fontFamily in fontFamilies)
            {
                comboBoxFontStyle.Items.Add(fontFamily.Name);
            }
            comboBoxFontStyle.SelectedItem = "Consolas";
        }

        private void PopulateColorComboBox()
        {
            foreach (KnownColor knownColor in Enum.GetValues(typeof(KnownColor)))
            {
                Color color = Color.FromKnownColor(knownColor);
                comboBoxColor.Items.Add(knownColor);
            }
            comboBoxColor.SelectedItem = KnownColor.Black;
        }

        private void PopulateSizeComboBox()
        {
            for (int i = 2; i < 46;)
            {
                comboBoxSize.Items.Add(i);
                i += 2;
            }
            comboBoxSize.SelectedItem = 12;
        }
        private void comboBoxColor_SelectedIndexChanged(object sender, EventArgs e)
        {
            KnownColor selectedColor = (KnownColor)comboBoxColor.SelectedItem;
            Color color = Color.FromKnownColor(selectedColor);

            richTextBox1.ForeColor = color;
        }

        private void comboBoxFrontStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            string? selectedFontFamily = comboBoxFontStyle.SelectedItem.ToString();
            richTextBox1.Font = new Font(selectedFontFamily!, 12);
        }

        private void comboBoxSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedSize = (int)comboBoxSize.SelectedItem;

            richTextBox1.Font = new Font(richTextBox1.Font.FontFamily, selectedSize);
        }

        private void btnBold_Click(object sender, EventArgs e)
        {
            ToggleFontStyle(FontStyle.Bold);
        }
        private void btnItalic_Click(object sender, EventArgs e)
        {
            ToggleFontStyle(FontStyle.Italic);
        }
        private void btnUnderline_Click(object sender, EventArgs e)
        {
            ToggleFontStyle(FontStyle.Underline);
        }
        private void ToggleFontStyle(FontStyle style)
        {
            if (richTextBox1.SelectionFont != null)
            {
                FontStyle currentStyle = richTextBox1.SelectionFont.Style;

                FontStyle newStyle = currentStyle ^ style;
                richTextBox1.SelectionFont = new Font(richTextBox1.SelectionFont, newStyle);
            }
        }
        private void left_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionAlignment = HorizontalAlignment.Left;
        }
        private void center_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionAlignment = HorizontalAlignment.Center;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectionAlignment = HorizontalAlignment.Right;
        }

        private void loadbtn_Click(object sender, EventArgs e)
        {
            string jsonFilePath = textBox1.Text + ".json";

            try
            {
                string jsonContent = File.ReadAllText(jsonFilePath);

                string textToLoad = JsonConvert.DeserializeObject<string>(jsonContent);

                richTextBox1.Text = textToLoad;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading JSON file: " + ex.Message, "Error");
            }
        }

        private void sevbtn_Click(object sender, EventArgs e)
        {
            string jsonFilePath = textBox1.Text + ".json";

            string textToSave = richTextBox1.Text;

            string jsonContent = JsonConvert.SerializeObject(textToSave, Formatting.Indented);

            try
            {
                File.WriteAllText(jsonFilePath, jsonContent);
                MessageBox.Show("JSON file saved successfully.", "Success");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving JSON file: " + ex.Message, "Error");
            }
        }
    }
}