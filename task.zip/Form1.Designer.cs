﻿namespace WinFormsApp8
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            richTextBox1 = new RichTextBox();
            comboBoxFontStyle = new ComboBox();
            comboBoxSize = new ComboBox();
            left = new Button();
            center = new Button();
            button3 = new Button();
            comboBoxColor = new ComboBox();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            btnUnderline = new Button();
            btnBold = new Button();
            btnItalic = new Button();
            label5 = new Label();
            loadbtn = new Button();
            sevbtn = new Button();
            SuspendLayout();
            // 
            // richTextBox1
            // 
            richTextBox1.BorderStyle = BorderStyle.None;
            richTextBox1.Cursor = Cursors.IBeam;
            richTextBox1.EnableAutoDragDrop = true;
            richTextBox1.Location = new Point(-2, 125);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(1098, 514);
            richTextBox1.TabIndex = 0;
            richTextBox1.Text = "";
            // 
            // comboBoxFontStyle
            // 
            comboBoxFontStyle.FormattingEnabled = true;
            comboBoxFontStyle.Location = new Point(37, 74);
            comboBoxFontStyle.Name = "comboBoxFontStyle";
            comboBoxFontStyle.Size = new Size(146, 33);
            comboBoxFontStyle.TabIndex = 1;
            comboBoxFontStyle.SelectedIndexChanged += comboBoxFrontStyle_SelectedIndexChanged;
            // 
            // comboBoxSize
            // 
            comboBoxSize.FormattingEnabled = true;
            comboBoxSize.Location = new Point(189, 74);
            comboBoxSize.Name = "comboBoxSize";
            comboBoxSize.Size = new Size(61, 33);
            comboBoxSize.TabIndex = 2;
            comboBoxSize.SelectedIndexChanged += comboBoxSize_SelectedIndexChanged;
            // 
            // left
            // 
            left.Image = Properties.Resources._4daa184ac45d35b3ec889ab170cd654d86bfc8f4ffba28ba2a23a27fc036f349_;
            left.Location = new Point(432, 70);
            left.Name = "left";
            left.Size = new Size(39, 38);
            left.TabIndex = 3;
            left.UseVisualStyleBackColor = true;
            left.Click += left_Click;
            // 
            // center
            // 
            center.Image = Properties.Resources._4daa184ac45d35b3ec889ab170cd654d86bfc8f4ffba28ba2a23a27fc036f349__;
            center.Location = new Point(477, 70);
            center.Name = "center";
            center.Size = new Size(39, 38);
            center.TabIndex = 4;
            center.UseVisualStyleBackColor = true;
            center.Click += center_Click;
            // 
            // button3
            // 
            button3.Image = Properties.Resources._4daa184ac45d35b3ec889ab170cd654d86bfc8f4ffba28ba2a23a27fc036f349___;
            button3.Location = new Point(522, 70);
            button3.Name = "button3";
            button3.Size = new Size(39, 38);
            button3.TabIndex = 5;
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // comboBoxColor
            // 
            comboBoxColor.FormattingEnabled = true;
            comboBoxColor.Location = new Point(591, 71);
            comboBoxColor.Name = "comboBoxColor";
            comboBoxColor.Size = new Size(114, 33);
            comboBoxColor.TabIndex = 6;
            comboBoxColor.SelectedIndexChanged += comboBoxColor_SelectedIndexChanged;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(744, 27);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(201, 31);
            textBox1.TabIndex = 7;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(744, 74);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(201, 31);
            textBox2.TabIndex = 8;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(90, 30);
            label1.Name = "label1";
            label1.Size = new Size(54, 28);
            label1.TabIndex = 9;
            label1.Text = "Font";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(189, 30);
            label2.Name = "label2";
            label2.Size = new Size(56, 28);
            label2.TabIndex = 10;
            label2.Text = " Size";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(441, 30);
            label3.Name = "label3";
            label3.Size = new Size(111, 28);
            label3.TabIndex = 11;
            label3.Text = "Alignment";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(617, 30);
            label4.Name = "label4";
            label4.Size = new Size(62, 28);
            label4.TabIndex = 12;
            label4.Text = "Color";
            // 
            // btnUnderline
            // 
            btnUnderline.Image = Properties.Resources.U;
            btnUnderline.Location = new Point(323, 70);
            btnUnderline.Name = "btnUnderline";
            btnUnderline.Size = new Size(37, 38);
            btnUnderline.TabIndex = 13;
            btnUnderline.UseVisualStyleBackColor = true;
            btnUnderline.Click += btnUnderline_Click;
            // 
            // btnBold
            // 
            btnBold.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnBold.Image = Properties.Resources.unnamed;
            btnBold.Location = new Point(278, 70);
            btnBold.Name = "btnBold";
            btnBold.Size = new Size(37, 39);
            btnBold.TabIndex = 14;
            btnBold.UseVisualStyleBackColor = true;
            btnBold.Click += btnBold_Click;
            // 
            // btnItalic
            // 
            btnItalic.Image = Properties.Resources.İ;
            btnItalic.Location = new Point(366, 70);
            btnItalic.Name = "btnItalic";
            btnItalic.Size = new Size(37, 39);
            btnItalic.TabIndex = 15;
            btnItalic.UseVisualStyleBackColor = true;
            btnItalic.Click += btnItalic_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(278, 30);
            label5.Name = "label5";
            label5.Size = new Size(121, 28);
            label5.TabIndex = 16;
            label5.Text = "  FrontStyle";
            // 
            // loadbtn
            // 
            loadbtn.Location = new Point(970, 25);
            loadbtn.Name = "loadbtn";
            loadbtn.Size = new Size(112, 34);
            loadbtn.TabIndex = 17;
            loadbtn.Text = "Load";
            loadbtn.UseVisualStyleBackColor = true;
            loadbtn.Click += loadbtn_Click;
            // 
            // sevbtn
            // 
            sevbtn.Location = new Point(970, 71);
            sevbtn.Name = "sevbtn";
            sevbtn.Size = new Size(112, 34);
            sevbtn.TabIndex = 18;
            sevbtn.Text = "Save";
            sevbtn.UseVisualStyleBackColor = true;
            sevbtn.Click += sevbtn_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1094, 639);
            Controls.Add(sevbtn);
            Controls.Add(loadbtn);
            Controls.Add(label5);
            Controls.Add(btnItalic);
            Controls.Add(btnBold);
            Controls.Add(btnUnderline);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(comboBoxColor);
            Controls.Add(button3);
            Controls.Add(center);
            Controls.Add(left);
            Controls.Add(comboBoxSize);
            Controls.Add(comboBoxFontStyle);
            Controls.Add(richTextBox1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox richTextBox1;
        private ComboBox comboBoxFontStyle;
        private ComboBox comboBoxSize;
        private Button left;
        private Button center;
        private Button button3;
        private ComboBox comboBoxColor;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button btnUnderline;
        private Button btnBold;
        private Button btnItalic;
        private Label label5;
        private Button loadbtn;
        private Button sevbtn;
    }
}